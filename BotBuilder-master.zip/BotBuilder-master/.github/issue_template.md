## Bot Info
* SDK Platform: <!-- .NET or Node.js -->
* SDK Version: <!-- SDK version -->
* Active Channels: <!-- Skype, MS Teams, Slack, Direct Line, etc. -->
* Deployment Environment: <!-- Azure Bot Service, Azure App Service, local development with Emulator? -->

## Issue Description
<!-- Describe your issue, question, or feature request -->

## Code Example
<!-- The bot code that reproduces the issue -->

## Reproduction Steps
1.
2.
3.

## Expected Behavior
<!-- What you expected to happen. -->

## Actual Results
<!-- What actually happened. Please give examples and support it with screenshots, copied output or error messages. -->
