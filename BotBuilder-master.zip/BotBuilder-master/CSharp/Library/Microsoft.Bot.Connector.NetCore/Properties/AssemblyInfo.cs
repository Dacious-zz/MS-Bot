﻿using System.Reflection;
using System.Resources;

[assembly: AssemblyVersion("3.13.1.0")]
[assembly: AssemblyFileVersion("3.13.1.0")]

//[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")] 
//[assembly: AssemblyDelaySignAttribute(true)]
